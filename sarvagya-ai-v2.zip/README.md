# Sarvagya-AI 2.0

Next-level educational AI tool with:
- 🧠 AI-powered accounting Q&A
- 📘 Journal entry simulation
- 📂 Ledger generator
- 💬 Daily student motivation

Made by GPT-X Brahma 🚀
